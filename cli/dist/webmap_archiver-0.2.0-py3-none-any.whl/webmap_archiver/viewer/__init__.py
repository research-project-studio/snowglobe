"""HTML viewer generation."""
