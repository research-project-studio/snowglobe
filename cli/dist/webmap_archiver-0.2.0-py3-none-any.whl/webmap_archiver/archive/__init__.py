"""Archive packaging and manifest generation."""
