"""HAR file parsing and classification."""
